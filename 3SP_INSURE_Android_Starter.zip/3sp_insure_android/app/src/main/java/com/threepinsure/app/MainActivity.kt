package com.threepinsure.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private val siteUrl = "https://headless-igfetajhngc-sudheeshgic-140b.wix-site-host.com/"
    private val navy = Color.rgb(6, 26, 58)
    private val gold = Color.rgb(217, 165, 43)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(navy)
        }
        val brand = TextView(this).apply {
            text = "3SP INSURE"
            textSize = 21f
            setTextColor(gold)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, 52, 1f))
        val whatsapp = Button(this).apply {
            text = "WhatsApp"
            setTextColor(navy)
            setBackgroundColor(gold)
            setOnClickListener { openWhatsApp() }
        }
        header.addView(whatsapp)
        root.addView(header)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(gold)
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 4))

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
            }
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                if (url.startsWith("http://") || url.startsWith("https://")) return false
                return try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); true }
                catch (_: Exception) { false }
            }
        }
        webView.webChromeClient = WebChromeClient()
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 6, 8, 6)
            setBackgroundColor(navy)
        }
        val reload = Button(this).apply { text = "Home / Refresh"; setOnClickListener { webView.loadUrl(siteUrl) } }
        val contact = Button(this).apply { text = "Call"; setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:9447843384"))) } }
        footer.addView(reload, LinearLayout.LayoutParams(0, -2, 1f))
        footer.addView(contact, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(footer)

        setContentView(root)
        webView.loadUrl(siteUrl)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun openWhatsApp() {
        val uri = Uri.parse("https://wa.me/919447843384?text=Hello%203SP%20INSURE%2C%20I%20would%20like%20insurance%20details.")
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { Toast.makeText(this, "WhatsApp is not available on this device", Toast.LENGTH_LONG).show() }
    }
}
