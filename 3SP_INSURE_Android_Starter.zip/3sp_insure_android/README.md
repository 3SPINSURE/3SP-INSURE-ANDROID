# 3SP INSURE Android starter project

This is an Android Studio starter project for an Android app named **3SP INSURE**.

## Included in this first build
- Loads the current published 3SP INSURE website inside the app, so the website's published pages/content remain the source of truth.
- Navy-blue header with gold brand treatment.
- WhatsApp enquiry shortcut to +91 94478 43384.
- Call shortcut to 9447843384.
- Back navigation and page refresh.

## Build
1. Install Android Studio on a computer (Windows, macOS, or Linux).
2. Open this project folder in Android Studio.
3. Let Gradle sync and install the Android SDK requested by the IDE.
4. Run on an Android phone for testing, then generate a signed Android App Bundle (AAB) for Google Play Console.

## Before publishing
- Verify the website URL and all pages on a real Android device.
- Add a proper app icon, privacy policy URL, support contact, and Play Store screenshots.
- Complete Google Play Console account registration and any required identity / testing steps.
- Review Google Play policies for WebView apps and insurance/financial-services content. This starter is not yet a Play Store-ready release.

Package name: `com.threepinsure.app`
Version: `1.0` (starter)
